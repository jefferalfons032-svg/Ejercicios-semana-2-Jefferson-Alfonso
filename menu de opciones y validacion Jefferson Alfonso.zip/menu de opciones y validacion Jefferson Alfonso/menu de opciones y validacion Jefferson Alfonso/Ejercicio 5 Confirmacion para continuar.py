# Ejercicio 5: Confirmación para continuar

respuesta = "S"

while respuesta == "S" or respuesta == "s":
    print("Procesando solicitud...")
    print("Solicitud procesada correctamente.")

    respuesta = input("¿Desea realizar otra operación? (S/N): ")

print("Proceso finalizado.")